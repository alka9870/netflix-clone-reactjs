
const Sdata = [
    {
        id:1,
        sname: 'DARK',
        imgsrc:"https://occ-0-3194-2164.1.nflxso.net/dnm/api/v6/6AYY37jfdO6hpXcMjf9Yu5cnmO0/AAAABVLn6xY1bOI5mPeAZpU6v7wafhinJ0mnG3D1TKZM_Zv79mQIdxW9P41ZGyMcyxN4xI5vhRMyfF_6F4tsKCKxsGrXirLt-h32Ar1B.jpg?r=077",
        title:"A Original Series",
        link:'https://www.netflix.com/in/title/80100172',
    },
    {
        id:2,
        sname: 'Stranger Things',
        imgsrc:"https://occ-0-3194-2164.1.nflxso.net/dnm/api/v6/6AYY37jfdO6hpXcMjf9Yu5cnmO0/AAAABer7SeWc6FvkBqWtk61GwL7rshAEVCOARQZVTEJGnLXykYBlO4nbbr6gs7M650BjULuaN6hucXKr5xY2iqPAajrxXd70HawdJeuD.jpg?r=608",
        title:"A Original Series",
        link:'https://www.netflix.com/in/title/80100172',
    },
    {
        id:3,
        sname: 'The Vampire Dairies',
        imgsrc:"https://occ-0-3194-2164.1.nflxso.net/dnm/api/v6/6AYY37jfdO6hpXcMjf9Yu5cnmO0/AAAABQzNpOPoWq8rLqN6DNaFiImsTnjEYyP9hY0URN15LxYx4CY0k8-El8yqqP4adAcUVSZ3VNvpmp6Uso11FXS9YfHTQ1qdBBr-N8jZ.jpg?r=4c9",
        title:"A Original Series",
        link:'https://www.netflix.com/in/title/80100172',
    },
    {
        id:4,
        sname: 'My first-2 love',
        imgsrc:"https://occ-0-3194-2164.1.nflxso.net/dnm/api/v6/6AYY37jfdO6hpXcMjf9Yu5cnmO0/AAAABd9LAXhF2cbQd1JTHwFzqcd3kFo5n21l8LUqN8AHExCiCpKrK4LGBcoNeoPrIWiBYTw4-oHQSwUl2WuTH73UPVqJwxLX661pHaWc.jpg?r=1df",
        title:"A Original Series",
        link:'https://www.netflix.com/in/title/80100172',
    },
    {
        id:5,
        sname: 'A Good Doctor',
        imgsrc:"https://occ-0-3194-2164.1.nflxso.net/dnm/api/v6/6AYY37jfdO6hpXcMjf9Yu5cnmO0/AAAABRxCJSVdFN8lJ_eSVhGevvYMzk0OLAozpunjhrC_9J_8tREBn4_m2sOHLe9l1GzsTJMq_7yv4jyosYsybOtgBZrsrp59064oa5kL.jpg?r=9f0",
        title:"A Original Series",
        link:'https://www.netflix.com/in/title/80100172',
    },
    {
        id:6,
        sname: 'Stranger Things',
        imgsrc:"https://occ-0-3194-2164.1.nflxso.net/dnm/api/v6/6AYY37jfdO6hpXcMjf9Yu5cnmO0/AAAABer7SeWc6FvkBqWtk61GwL7rshAEVCOARQZVTEJGnLXykYBlO4nbbr6gs7M650BjULuaN6hucXKr5xY2iqPAajrxXd70HawdJeuD.jpg?r=608",
        title:"A Original Series",
        link:'https://www.netflix.com/in/title/80100172',
    },
];

export default Sdata;