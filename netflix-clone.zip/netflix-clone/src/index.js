import React from "react";
import ReactDOM from "react-dom";
import './index.css';
import App from './App';


// console.log(Sdata[0].sname);
ReactDOM.render(<App/>,document.getElementById("root"));