import React from "react";
import Netflix from "./Netflix";
import Amazon from "./Amazon";

const favSeries = 'youtube';

// const FavS = () =>{
// if (favSeries === 'netflix'){
//   return <Netflix/>;
// }else{
//   return <Amazon/>;
// }
// }

const App = () => (
  <>
    {/* <h1 className="heading__style"> List of top 5 Netflix Series in 2009 </h1>
    {Sdata.map((val, index) => {
      console.log(index);
      return (
        <Card
          key={val.id}
          imgsrc={val.imgsrc}
          title={val.title}
          sname={val.sname}
          link={val.link}
        />
      );
      })} */}
      {/* <FavS/> */}
      {(favSeries === 'netflix') ?  <Netflix/>: <Amazon/>}
  </>
);
  export default App;
